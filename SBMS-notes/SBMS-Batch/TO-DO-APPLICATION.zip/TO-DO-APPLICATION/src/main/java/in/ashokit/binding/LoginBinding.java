package in.ashokit.binding;

import javax.validation.constraints.NotEmpty;

public class LoginBinding {
	
	@NotEmpty(message = "username is required")
	private String username;
	
	@NotEmpty(message = "Password is required")
	private String password;
	
	public String getusername() {
		return username;
	}
	public void setusername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	

}
