package in.ashokit.binding;

import in.ashokit.entity.UserEntity;

public class TaskBinding {

	private String taskName;
	
	private String taskDate;
	
	private String timing;
	
	private UserEntity user;
	

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getTaskDate() {
		return taskDate;
	}

	public void setTaskDate(String taskDate) {
		this.taskDate = taskDate;
	}

	public String getTiming() {
		return timing;
	}

	public void setTiming(String timing) {
		this.timing = timing;
	}

	public UserEntity getUser() {
		return user;
	}

	public void setUser(UserEntity user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "TaskBinding [taskName=" + taskName + ", taskDate=" + taskDate + ", timing=" + timing + "]";
	}

}
