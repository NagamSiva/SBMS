package in.ashokit.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import in.ashokit.entity.UserEntity;

@Repository
public interface UserRepo extends JpaRepository<UserEntity, Integer> {


public UserEntity findByNameAndPassword(String username, String password);

public UserEntity findByName(String name);

}
