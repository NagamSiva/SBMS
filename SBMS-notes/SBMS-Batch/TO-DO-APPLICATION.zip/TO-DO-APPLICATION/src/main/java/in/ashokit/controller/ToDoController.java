package in.ashokit.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import in.ashokit.binding.LoginBinding;
import in.ashokit.binding.TaskBinding;
import in.ashokit.binding.UserBinding;
import in.ashokit.entity.TaskEntity;
import in.ashokit.entity.UserEntity;
import in.ashokit.repository.TaskRepo;
import in.ashokit.repository.UserRepo;

@Controller
public class ToDoController {

	@Autowired
	private UserRepo userRepo;

	@Autowired
	private TaskRepo taskRepo;

	int userId;

	@GetMapping("/")
	public String loginForm(Model model) {
		model.addAttribute("loginBinding", new LoginBinding());
		return "login";
	}

	@PostMapping("/welcome")
	public String welcomePage(@Valid LoginBinding binding, BindingResult result, HttpServletRequest request,
			Model model) {

		if (result.hasErrors()) {
			return "login";

		} else {
			String username=binding.getusername().toLowerCase();
			UserEntity user = userRepo.findByNameAndPassword(username, binding.getPassword());
			if (user != null) {
				HttpSession session = request.getSession();
				session.setAttribute("userName", username);
				return "home";
			} else {
				model.addAttribute("msg", "User Not found, Please Register...!!");
				return "login";
			}
		}
	}

	@GetMapping("/register")
	public String loadForm(Model model) {
		model.addAttribute("userBinding", new UserBinding());
		return "register";
	}

	@PostMapping("/save")
	public String saveUser(@Valid UserBinding u, BindingResult result, Model model) {

		if (result.hasErrors()) {
			return "register";
		} else {

			UserEntity userEntity = new UserEntity();

			BeanUtils.copyProperties(u, userEntity);
			userEntity.setName(u.getName().toLowerCase());
			
			UserEntity user = userRepo.findByName(u.getName());
			if (user == null) {
				userRepo.save(userEntity);
				model.addAttribute("msg", "User saved..!!");
			} else {
				model.addAttribute("msg", "User already exit..!!");
			}
			return "register";
		}

	}

	@GetMapping("/task")
	public String LoadTaskForm(Model model) {
		model.addAttribute("taskBinding", new TaskBinding());
		return "task";
	}

	@PostMapping("/saveTask")
	public String saveTaskForm(TaskBinding t, HttpSession session) {

		TaskEntity entity = new TaskEntity();
		entity.setTaskName(t.getTaskName());

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate date = LocalDate.parse(t.getTaskDate(), formatter);
		entity.setTaskDate(date);

		DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("HH:mm");
		LocalTime time = LocalTime.parse(t.getTiming(), formatter1);
		entity.setTiming(time);

		String name = (String) session.getAttribute("userName");

		// Find the User and set to task
		UserEntity user = userRepo.findByName(name);
		entity.setUser(user);

		// save task details
		taskRepo.save(entity);

		return "home";

	}

	@GetMapping("/show")
	public String showAllTask(HttpSession session, Model model) {

		String name = (String) session.getAttribute("userName");

		UserEntity user = userRepo.findByName(name);
		
		List<TaskEntity> taskList =user.getTask();
		
		model.addAttribute("name", name);
		model.addAttribute("tasks", taskList);

		return "showTasks";

	}
	
	    
	    @GetMapping("/logout")
	    public void logout(HttpServletRequest request, HttpServletResponse response, HttpSession session) throws IOException {
	        // invalidate session
	        if (session != null) {
	            session.invalidate();
	        }
	       
	        // redirect to home page
	        response.sendRedirect("/");
	    }
	    
	

}
