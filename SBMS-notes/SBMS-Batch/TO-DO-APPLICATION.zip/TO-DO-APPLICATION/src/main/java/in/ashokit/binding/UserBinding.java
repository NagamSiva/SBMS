package in.ashokit.binding;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class UserBinding {

	private Integer id;

	@Size(min = 3, max = 8)
	@NotNull(message = "Name is Required")
	private String name;

	@Email(message = "Enter correct email")
	private String email;

	@NotNull(message = "Password is Required")
	private String password;

	@NotNull(message = "Gender is Required")
	private String gender;

	@Pattern(regexp = "[6-9][0-9]{9}", message = "Enter valid mobile no")
	private String phno;

	// private List<TaskEntity> task;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getPhno() {
		return phno;
	}

	public void setPhno(String phno) {
		this.phno = phno;
	}
	/*
	 * public List<TaskEntity> getTask() { return task; } public void
	 * setTask(List<TaskEntity> task) { this.task = task; }
	 * 
	 * @Override public String toString() { return "UserBinding [id=" + id +
	 * ", name=" + name + ", email=" + email + ", password=" + password +
	 * ", gender=" + gender + ", phno=" + phno + ", task=" + task + "]"; }
	 */

}
